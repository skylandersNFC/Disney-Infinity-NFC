如何烧写固件：

方法一：线刷
此方法需要额外购买CMASS-DAP兼容的下载器，推荐9.9元的pwlink2 lite
购买地址：https://item.taobao.com/item.htm?spm=a1z09.2.0.0.4b942e8deXyaQO&id=675067753017&_u=d2p75qfn774a

连接好线后双击fw_update.bat烧写固件。

方法二：OTA更新
此方法仅适用于已经通过线刷成功的Pixl.js设备。
安装nrfconnect应用（iOS、Android都支持），设备在 设置 菜单中选择 ”固件更新“ 菜单后，设备会进入DFU模式，然后使用nrfconnect连接名为pixl dfu设备更新固件。
固件是压缩包里面的pixjs_ota_vxxx.zip，需要通过微信或者QQ分享给nrfconnect应用。